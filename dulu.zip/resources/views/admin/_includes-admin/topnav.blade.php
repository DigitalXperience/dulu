<nav class="navbar topNav">
        <div class="container">
            <div class="navbar-brand">
                <a class="navbar-item" href="accueil">
                    MyDULU WEAR
                </a>
                <div class="navbar-burger burger" data-target="">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <div class="navbar-end">
                <div class="navbar-item">
                    <div class="field is-grouped">
                        <p class="control">
                            <a class="" href="#">
                                <i class="fa fa-user-circle"></i>
                            </a>
                            <span>{{session('user_name')}}</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </nav>