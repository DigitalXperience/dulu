<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>MyDULU WEAR - Invitations</title>
  <link rel="shortcut icon" type="image/png" href="assets/img/gulu_logo.png">

  <script src="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.min.js')); ?>"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/reset.min.css')); ?>">
<link rel='stylesheet' href='<?php echo e(asset('assets/css/bulma.css')); ?>'>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dulu_member_style.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/invitations.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

</head>
<body>

    <?php echo $__env->make('_includes.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('_includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- partial:index.partial.html -->
<div class="container2">
        <div class="container-top">
            <div class="left">
                <h2>Suivie des invitations</h2>
                <p>Vous pouvez envoyer des invitations aussi</p>
            </div>
            <div class="right">
                <button id="createNew">Envoyer</button>
            </div>
        </div>
        <div class="container-body">
            <table id="table">
                <tr>
                  <th>Membre</th>
                  <th>Date</th>
                  <th>Status</th>
                </tr>
                    <?php
                    $i=1
                    ?>
                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->NOM); ?> <?php echo e($user->PRENOM); ?></td>
                        <td><?php echo e($user->created_at); ?></td>
                        <td><?php echo e($user->STATUT); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
    <div class="modal" id="modal">
        <div class="modal-container">
            <form id="form">
                <h2>Envoyer une invitation</h2>
                <div class="form-group">
                    <label for="link">Votre lien</label>
                    <input type="text" id="link"  class="form-control" value="https://duluwear.com/?ref=<?php echo e(session('user_id')); ?>" required disabled>
                </div>
                <button class="btn btn-success" onclick="copyToClipboard()">Copiez le lien</button>
            </form>
        </div>
    </div>
</body>

</html>
<!-- partial -->
  <script  src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
  <script  src="<?php echo e(asset('assets/js/invitations.js')); ?>"></script>
  <script src="assets/js/jquery-3.5.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js" ></script>
    <script src="assets/js/jquery-3.3.1.slim.min.js" ></script>
    <script src="assets/js/popper.min.js" ></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\dulu\resources\views//invitations.blade.php ENDPATH**/ ?>