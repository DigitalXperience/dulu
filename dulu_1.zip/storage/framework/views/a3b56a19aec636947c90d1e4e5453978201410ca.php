




<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>MyDULU WEAR - Invitations</title>

  <link href="<?php echo e(asset('https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css')); ?>" rel="stylesheet" id="bootstrap-css">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css')); ?>">
<link rel='stylesheet' href='<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css')); ?>'>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dulu_member_style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/commande.css')); ?>">

</head>
<body>

    <?php echo $__env->make('_includes.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('_includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <!-- partial:index.partial.html -->
    <div class="container2">
        <div class="container-body">
            <table id="table">
                <tr>
                  <th>Product Name</th>
                  <th>Product Quantity</th>
                  <th>Product unic price</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Numero de telephone</th>
                  <th>Date de creation</th>

                </tr>
                    <?php
                        $i=1
                    ?>
                    <?php $__currentLoopData = $commande; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $price=$user->PRODUCT_PRICE*$user->PRODUCT_QUANTITY;
                        ?>
                        <?php switch($user->DILIVARY_STATUS): 
                            case ('1'): ?>
                                <?php
                                    $Status='EN ATTENTE'    
                                ?>
                                
                                <?php break; ?>
                            <?php case ("2"): ?>
                                <?php
                                    $Status='EN COURS'    
                                ?>
                                <?php break; ?>
                            <?php case ("3"): ?>
                                <?php
                                    $Status='LIVRAIE'    
                                ?>
                                <?php break; ?>
                            <?php default: ?>
                                <?php
                                    $Status='ANNULE'    
                                ?>
                        <?php endswitch; ?>
                        <tr>
                            <td><?php echo e($user->PRODUCT_NAME); ?></td>
                            <td><?php echo e($user->PRODUCT_QUANTITY); ?></td>
                            <td><?php echo e($user->PRODUCT_PRICE); ?></td>  
                            <td><?php echo e($price); ?></td>
                            <td><?php echo e($Status); ?></td>
                            <td><?php echo e($user->USER_TELEPHONE); ?></td>
                            <td><?php echo e($user->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

        
            
        </div>
    </div>
</body>

</html>

<!-- partial -->
  <script  src="<?php echo e(asset('assets/js/dulu_member_script.js')); ?>"></script>
  <script  src="<?php echo e(asset('assets/js/invitations.js')); ?>"></script>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.6/dist/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>

    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\dulu\resources\views//mescommandes.blade.php ENDPATH**/ ?>