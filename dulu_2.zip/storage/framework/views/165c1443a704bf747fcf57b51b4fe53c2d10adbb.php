<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>MyDULU WEAR - ADMIN</title>
  <link rel="shortcut icon" type="image/png" href="assets/img/gulu_logo.png">

  <script src="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.min.js')); ?>"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css')); ?>">
<link rel='stylesheet' href='<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css')); ?>'>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/dulu_member_style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/arbre.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">


</head>
<body>
<!-- partial:index.partial.html -->
<!-- Check out the dark themed version on my github: https://github.com/emkelley -->


<body>
    

    <?php echo $__env->make('admin._includes-admin.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin._includes-admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="tree">
            <ul>
                <li>
                    <a href="#"><?php echo e(session('user_name')); ?></a>
                    <ul>
                        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="#"><?php echo e($user->PRENOM); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</body>

</html>
<!-- partial -->
<script  src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\dulu\resources\views/admin/arbre.blade.php ENDPATH**/ ?>