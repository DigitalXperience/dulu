<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\dulu\resources\views//name.blade.php ENDPATH**/ ?>